<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'jeremykenedy/laravel-exception-notifier' => 
  array (
    'providers' => 
    array (
      0 => 'jeremykenedy\\laravelexceptionnotifier\\LaravelExceptionNotifier',
    ),
  ),
  'jeremykenedy/laravel-roles' => 
  array (
    'providers' => 
    array (
      0 => 'jeremykenedy\\LaravelRoles\\RolesServiceProvider',
    ),
  ),
  'laravel/socialite' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Socialite\\SocialiteServiceProvider',
    ),
    'aliases' => 
    array (
      'Socialite' => 'Laravel\\Socialite\\Facades\\Socialite',
    ),
  ),
  'socialiteproviders/manager' => 
  array (
    'providers' => 
    array (
      0 => 'SocialiteProviders\\Manager\\ServiceProvider',
    ),
  ),
  'rap2hpoutre/laravel-log-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Rap2hpoutre\\LaravelLogViewer\\LaravelLogViewerServiceProvider',
    ),
  ),
  'barryvdh/laravel-debugbar' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\Debugbar\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Debugbar' => 'Barryvdh\\Debugbar\\Facade',
    ),
  ),
  'creativeorange/gravatar' => 
  array (
    'providers' => 
    array (
      0 => 'Creativeorange\\Gravatar\\GravatarServiceProvider',
    ),
    'aliases' => 
    array (
      'Gravatar' => 'Creativeorange\\Gravatar\\Facades\\Gravatar',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'laravelcollective/html' => 
  array (
    'providers' => 
    array (
      0 => 'Collective\\Html\\HtmlServiceProvider',
    ),
    'aliases' => 
    array (
      'Form' => 'Collective\\Html\\FormFacade',
      'Html' => 'Collective\\Html\\HtmlFacade',
    ),
  ),
  'webpatser/laravel-uuid' => 
  array (
    'aliases' => 
    array (
      'Uuid' => 'Webpatser\\Uuid\\Uuid',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'imanghafoori/laravel-widgetize' => 
  array (
    'providers' => 
    array (
      0 => 'Imanghafoori\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
  ),
  'barryvdh/laravel-dompdf' => 
  array (
    'providers' => 
    array (
      0 => 'Barryvdh\\DomPDF\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'PDF' => 'Barryvdh\\DomPDF\\Facade',
    ),
  ),
  'pusher/pusher-http-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pusher\\Laravel\\PusherServiceProvider',
    ),
    'aliases' => 
    array (
      'Pusher' => 'Pusher\\Laravel\\Facades\\Pusher',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'amranidev/scaffold-interface' => 
  array (
    'providers' => 
    array (
      0 => 'Amranidev\\ScaffoldInterface\\ScaffoldInterfaceServiceProvider',
    ),
  ),
  'crestapps/laravel-code-generator' => 
  array (
    'providers' => 
    array (
      0 => 'CrestApps\\CodeGenerator\\CodeGeneratorServiceProvider',
    ),
  ),
  'encore/laravel-admin' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\AdminServiceProvider',
    ),
    'aliases' => 
    array (
      'Admin' => 'Encore\\Admin\\Facades\\Admin',
    ),
  ),
  'laravel-admin-ext/reporter' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Reporter\\ReporterServiceProvider',
    ),
  ),
  'laravel-admin-ext/log-viewer' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\LogViewer\\LogViewerServiceProvider',
    ),
  ),
  'laravel-admin-ext/scheduling' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Scheduling\\SchedulingServiceProvider',
    ),
  ),
  'spatie/laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Backup\\BackupServiceProvider',
    ),
  ),
  'laravel-admin-ext/backup' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Backup\\BackupServiceProvider',
    ),
  ),
  'laravel-admin-ext/config' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Config\\ConfigServiceProvider',
    ),
  ),
  'laravel-admin-ext/helpers' => 
  array (
    'providers' => 
    array (
      0 => 'Encore\\Admin\\Helpers\\HelpersServiceProvider',
    ),
  ),
);