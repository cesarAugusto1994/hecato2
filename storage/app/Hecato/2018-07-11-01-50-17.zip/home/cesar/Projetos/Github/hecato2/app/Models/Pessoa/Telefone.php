<?php

namespace App\Models\Pessoa;

use Illuminate\Database\Eloquent\Model;

class Telefone extends Model
{
    protected $table = 'pessoa_telefones';
}
