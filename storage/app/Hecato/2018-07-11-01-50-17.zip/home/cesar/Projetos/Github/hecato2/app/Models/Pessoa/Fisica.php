<?php

namespace App\Models\Pessoa;

use Illuminate\Database\Eloquent\Model;

class Fisica extends Model
{
    protected $table = 'pessoa_fisica';
}
