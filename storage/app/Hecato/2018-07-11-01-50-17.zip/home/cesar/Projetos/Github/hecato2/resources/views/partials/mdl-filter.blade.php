<div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable search-white">
	<label class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect mdl-button--icon" for="search_info">
	  	<i class="material-icons">filter_list</i>
	</label>
	<div class="mdl-textfield__expandable-holder">
	  	<input class="mdl-textfield__input" type="search" id="search_info" name="search_info" placeholder="Filter term..">
	  	<label class="mdl-textfield__label" for="search_info">
	  		Filter term...
	  	</label>
	</div>
</div>