<?php

namespace App\Models\Pessoa;

use Illuminate\Database\Eloquent\Model;

class Juridica extends Model
{
    protected $table = 'pessoa_juridica';
}
