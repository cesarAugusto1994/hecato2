<?php

return [

    // Permissions
    'permissionView'      => 'Visualizar',
    'permissionCreate'    => 'Criar',
    'permissionEdit'      => 'Editar',
    'permissionDelete'    => 'Deletar',

];
