<?php

namespace App\Models\Schedule;

use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    protected $table = 'agenda_status';
}
