<div class="mdl-textfield mdl-js-textfield mdl-textfield--expandable search-white">
	<label class="mdl-button mdl-button--icon mdl-js-button mdl-js-ripple-effect mdl-button--icon" for="highlight_info" style="top: 16px" title="Highlight terms(s)">
	  	<i class="material-icons">highlight</i>
	  	<span class="sr-only">Highlight terms(s)</span>
	</label>
	<div class="mdl-textfield__expandable-holder">
	  	<input class="mdl-textfield__input" type="search" id="highlight_info" name="highlight_info" placeholder="Highlight term..">
	  	<label class="mdl-textfield__label" for="highlight_info">
	  		Highlight term...
	  	</label>
	</div>
</div>