<?php

namespace App\Models\Empresa;

use Illuminate\Database\Eloquent\Model;

class Contato extends Model
{
    //
}
