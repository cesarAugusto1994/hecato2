<?php

namespace App\Models\Pessoa;

use Illuminate\Database\Eloquent\Model;

class Endereco extends Model
{
    protected $table = 'pessoa_enderecos';
}
