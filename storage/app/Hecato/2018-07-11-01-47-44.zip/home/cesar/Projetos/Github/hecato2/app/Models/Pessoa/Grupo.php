<?php

namespace App\Models\Pessoa;

use Illuminate\Database\Eloquent\Model;

class Grupo extends Model
{
    protected $table = 'grupo_pessoas';
}
